#define DEBUG_LABEL(x) asm volatile(#x ":");
